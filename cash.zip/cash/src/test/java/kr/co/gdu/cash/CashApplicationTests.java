package kr.co.gdu.cash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CashApplicationTests {

	@Test
	void contextLoads() {
	}

}
